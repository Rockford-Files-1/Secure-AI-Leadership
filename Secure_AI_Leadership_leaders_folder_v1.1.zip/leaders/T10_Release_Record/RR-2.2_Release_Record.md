---
title: "Release Record RR-2.2"
subtitle: "Advising Agent, Version 2.2 — Completed example of Template T10"
---

*Companion to* Secure AI Leadership, *Chapter 10. Illustrative example: the university, names, dates, identifiers, and figures are fictional. Copy and adapt the blank Template T10 for your own decisions.*

## System and Version

| Item | Entry |
|---|---|
| System | Advising agent (university advising assistant for students and advisors) |
| Version | 2.2 |
| Release manifest | RM-2.2, dated November 2, 2027: pinned vendor model (new version, after the vendor retired the version pinned in RM-2.1), instructions IN-2.2, tools per authority matrix T4-2.2, approved sources per T3 records, and settings ST-2.2 |
| Decision date | Friday, November 5, 2027, 9:40 a.m. |
| Planned activation | Monday, November 8, 2027, when spring registration opens, subject to the conditions below and to readiness confirmation (Chapter 11) |

## Decision

**Approve with conditions.** Gate 7 failed. Student-facing transfer-credit answers are not released.

## Scope

| Covered | Excluded |
|---|---|
| All Version 2.2 functions for about 14,000 students and all advisors, as listed in T4-2.2 | Student-facing transfer-credit answers |
| Transfer-credit drafts visible only to advisors, under exception E-2.2-01 | Any action that registers, drops, or changes a course or records a transfer-credit decision (prohibited in every version) |

## Intended Benefit and Baseline

| Item | Entry |
|---|---|
| Benefit | Less advisor time on routine transfer-credit questions during registration, so advisors can see more students |
| Measure | Median advisor time per transfer-credit question, from receipt to sent answer |
| Baseline | About 12 minutes (time study of 200 questions handled without the agent, October 2027; baseline report BL-2.2) |
| Expected with drafts | About 4 to 6 minutes, if drafts are accurate and review remains careful |
| Monitoring | Reported monthly; a month above 8 minutes prompts a review of whether drafting is worth its risks (Template T12) |

## Evidence Reviewed

| Item | Version and date | Notes |
|---|---|---|
| Release manifest | RM-2.2, November 2, 2027 | Matches the tested build; vendor model change recorded |
| Evaluation plan | EV-2.0, signed September 24, 2027; method checked by the office of institutional research, September 22, 2027 | No deviations after registration |
| Gate results | GR-2.2, November 3, 2027 | All twelve gates rerun on Version 2.2; rerun overseen by the registrar's office; individual questions not exposed; results not used to guide changes |
| Security findings | Access-control tests AC-2.2 and red-team report RT-2.2 (two weeks, adaptive, authorization RT-2.1) | No open high-severity findings; two medium findings fixed and retested |
| Exception request | ER-2.2-07, November 4, 2027 | From the engineering lead, for Gate 7 |
| Residual risk statement | RR-2.2, November 4, 2027 | Four significant risks; see below |
| Authority matrix | T4-2.2 | Tool inventory matches the matrix (permission review PR-2.2) |
| Monitoring plan | MP-2.2 | Triggers below |
| Rollback plan | RB-2.2, tested November 3, 2027 | Fallback to the portal's non-agent workflow in 9 minutes; Version 2.1 is not viable because it used the retired model |
| Approval history | RD-1.0 and RD-1.1 | Earlier conditions met; appointment booking review completed September 1, 2027 |
| Missing | None | |

## Gate Results

Thresholds were set in evaluation plan EV-2.0 before testing. Ranges are approximate 95 percent Wilson confidence intervals. Each gate's threshold is an observed-score threshold; a range describes precision and does not change a result.

| Gate | Threshold (EV-2.0) | Result | Range | Status |
|---|---|---|---|---|
| 1. Catalog and policy answer accuracy | At least 475 of 500 held-out questions | 484 of 500 (96.8 percent) | 94.9 to 98.0 percent | Pass |
| 2. Correct catalog year cited | At least 485 of 500 | 495 of 500 (99.0 percent) | 97.7 to 99.6 percent | Pass |
| 3. Access to another student's data | No demonstrated path | None found in direct tests or red teaming | Not applicable | Pass; passing does not show that no path exists |
| 4. Unauthorized official record change | No demonstrated path | None found | Not applicable | Pass |
| 5. Adaptive red team | No open high-severity finding | None open | Not applicable | Pass |
| 6. Tools match the authority matrix | Every enabled tool in T4-2.2, at its approved level | Matches | Not applicable | Pass |
| **7. Transfer-credit accuracy** | **At least 380 correct of all 400; referrals count as not correct** | **376 of 400 (94.0 percent)** | **91.2 to 95.9 percent** | **Fail** |
| 8. Transfer-credit serious errors | No more than 4 of 400 wrongly saying a course transfers | 3 of 400 | 0.3 to 2.2 percent | Pass |
| 9. Transfer-credit slices | Each college or catalog year with 40 or more questions: observed 90 percent | All such slices passed; Partner Colleges K and M (fewer than 40 questions each) inconclusive | Reported per slice in GR-2.2 | Pass, with two inconclusive slices |
| 10. Filter blocks ordinary questions | No more than 10 of 500 (2 percent) | 7 of 500 (1.4 percent) | 0.7 to 2.9 percent | Pass |
| 11. Filter blocks harmful requests | At least 285 of 300 (95 percent), including every tested request in the most severe category | 290 of 300 (96.7 percent); 60 of 60 most severe | 94.0 to 98.2 percent; 94.0 to 100 percent | Pass; does not show every severe request will be blocked in operation |
| 12. Fallback | Tested return to a viable prior state within 30 minutes | Non-agent workflow restored in 9 minutes | Not applicable | Pass |

**Gate 7 diagnostics** (reported, not gates): the agent answered 388 of 400 questions and referred 12; accuracy on answered questions was 376 of 388 (96.9 percent); advisors judged 11 of the 12 referrals appropriate.

## Exceptions

| Item | Entry |
|---|---|
| Exception | E-2.2-01, for Gate 7 |
| Failed criterion | Transfer-credit accuracy: 376 of 400 against a threshold of 380. Gate 7 applies to transfer-credit answers whether students or advisors receive them |
| Granted by | Daniel Osei, registrar, under the university's delegation of authority DA-2026 for academic-accuracy exceptions |
| What it permits | Transfer-credit drafts visible only to advisors, each approved or corrected by an advisor before anything reaches a student |
| What it never permits | Students receiving unreviewed transfer-credit answers |
| Period | November 8 through December 7, 2027 (30 calendar days, inclusive), unless renewed under the same authority |
| On expiry without renewal | Advisor-facing drafting stops. The drafting function is scheduled to switch off automatically at 12:00 a.m. on December 8, 2027; Ken Ito, engineering lead, is responsible for verifying and recording that morning that it has stopped |
| Path to student-facing answers | A revised version, treated as a new candidate, must pass the original 400 questions as a regression check and score at least 95 percent on 400 new held-out questions, held by the registrar's office, followed by a new release decision |

## Compensating Controls

Each control was tested in the release configuration before the approval took effect. Results are attached as ST-2.2.

| Control | Test | Result |
|---|---|---|
| Students cannot see unreviewed drafts | ST-2.2-01: student accounts, altered identifiers, and direct requests to the draft store | Pass, November 6, 2027 |
| Every draft needs an advisor's approval or correction before it is sent | ST-2.2-02: 200 test drafts; attempts to send without approval | Pass; no draft sent without approval |
| Approver and final response are recorded | ST-2.2-03: record check for each of the 200 test drafts | Pass; all recorded in action log AL-2.2 |
| Routing change does not affect gates 1 to 6 and 8 to 12 | ST-2.2-04: affected gates rerun in staging | Pass, no change in results |

**Approval took effect:** Saturday, November 6, 2027, when results ST-2.2-01 to 04 were attached, confirmed by Lena Fischer.

## Capacity

| Item | Entry |
|---|---|
| Expected demand | About 300 transfer-credit questions a day during registration (last spring's logs) |
| Confirmed capacity | Up to 300 draft reviews a day during registration, confirmed by the associate director of advising (capacity confirmation CC-2.2, November 4, 2027) |
| Backup reviewers | Up to 80 additional reviews a day from transfer admissions, confirmed by the director of admissions (CC-2.2-B, November 5, 2027) |
| Response promise | Advisor reply within two business days |
| Queue trigger | If pending drafts reach 450, about a day and a half of confirmed capacity, new transfer-credit requests are routed to appointments; requests already in the queue stay assigned until answered |
| Owner | Associate director of advising, who reviews the queue daily |

## Residual Risks Accepted for Operation

These risks were conditionally accepted at Assess. They are now accepted for operation on the evidence below, under delegation of authority DA-2026.

| Risk | Bound and evidence | Accepted by |
|---|---|---|
| R-21 An advisor approves an incorrect transfer-credit draft, and a student acts on it | Every draft reviewed (ST-2.2-02); serious errors within cap (Gate 8); same-day escalation of consequential errors; answers labeled preliminary | Daniel Osei, registrar, for academic accuracy |
| R-22 Disclosure of one student's data to another | No path found in direct tests or red teaming (Gates 3 and 5); drafts not visible to students (ST-2.2-01) | Chief information officer, for data security, on the security lead's review |
| R-23 Planted instructions on departmental pages steer answers | Adaptive red team included planted instructions; no open finding (Gate 5); approved-source controls (T3) | Chief information officer, for data security |
| R-24 Review queue exceeds capacity during registration | Capacity and backup confirmed; queue trigger at 450 | Dr. Maria Alvarez, for operational risk within the project's authority |

## Conditions

| Condition | Owner | How it is checked |
|---|---|---|
| Student-facing transfer-credit answers stay disabled | Ken Ito | Configuration check at activation and weekly |
| Drafts reviewed before release to students | Associate director of advising | Action log AL-2.2; weekly sample of 25 drafts |
| Queue trigger applied at 450 pending drafts | Associate director of advising | Daily queue report |
| Consequential errors escalated the same day; minor errors reported weekly | Associate director of advising | Error log; weekly report to Maria |
| Exception expires December 7 unless renewed | Daniel Osei (renewal decision); Ken Ito (switch-off confirmation) | Written confirmation December 8 |
| Model version stays pinned; any vendor change triggers an impact assessment | Ken Ito | Quarterly version check; vendor notices |

## Monitoring Triggers

| Signal | Threshold | Action | Who acts |
|---|---|---|---|
| Draft error affecting eligibility, cost, graduation, or registration | Any one | Same-day report to Maria and Ken Ito; Maria decides whether to suspend drafting | Associate director of advising; Maria |
| Pending drafts | 450 | Route new requests to appointments | Associate director of advising |
| Filter blocking ordinary questions | Above 3 percent in a week's sample | Review filter settings; report to Lena | Ken Ito |
| Access-control alert | Any | Suspend tools; investigate | Lena Fischer |
| Vendor model or subprocessor notice | Any | Impact assessment before change | Ken Ito; Maria |
| Advisor time per transfer-credit question (benefit) | Above 8 minutes for a month | Review whether drafting is worth its risks | Maria |

## Rollback

| Item | Entry |
|---|---|
| Method | Suspend Version 2.2 and restore the advising portal's previously approved non-agent workflow (catalog search, appointment booking, and advisor email); or switch off all tools while answers continue (Chapter 4). Version 2.1 is not a fallback, because it used the retired model |
| Tested | November 3, 2027; 9 minutes |
| Who may trigger | Lena Fischer or the associate director of advising, as named in T4-2.2; Maria may also order it |

## Review

| Item | Date or trigger |
|---|---|
| Exception E-2.2-01 expires | December 7, 2027, unless renewed |
| Approval review | Monday, February 7, 2028 |
| Earlier review | Any breached condition, consequential error pattern, or material change |
| Changes that invalidate this approval | A model, instruction, tool, or source change outside the agreed change process; a new user group; enabling student-facing transfer-credit answers |

## Approvers

| Role | Name | Signature | Date |
|---|---|---|---|
| Risk owner and release owner | Dr. Maria Alvarez, associate provost for student success | | November 5, 2027 |
| Second approver, independent of the build team; academic-accuracy risk acceptance (R-21); delegated exception authority | Daniel Osei, registrar | | November 5, 2027 |
| Risk acceptance (R-22, R-23) | Chief Information Officer | | November 5, 2027 |
| Security review | Lena Fischer, chief information security officer | | November 5, 2027 |
| Capacity confirmation | Associate Director of Advising | | November 4, 2027 |

*Prepared by Dr. Maria Alvarez with Ken Ito (engineering lead) and Lena Fischer (security lead). Attach the release package; keep the signed release record with the system's records.*
